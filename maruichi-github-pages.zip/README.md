# 焼きとん まるいち｜お勘定チェック

GitHub Pages で公開するための静的サイトです。

## 公開手順

1. **GitHubアカウントを作る**（まだなければ）: https://github.com/signup
2. **新しいリポジトリを作成**:
   - https://github.com/new にアクセス
   - リポジトリ名を入力（例: `maruichi-app`）
   - 「Public」を選択
   - 「Create repository」をクリック
3. **index.html をアップロード**:
   - 作成したリポジトリのページで「uploading an existing file」をクリック
   - この `index.html` をドラッグ&ドロップ
   - 「Commit changes」をクリック
4. **GitHub Pages を有効化**:
   - リポジトリの「Settings」タブを開く
   - 左メニューの「Pages」をクリック
   - 「Source」を `Deploy from a branch` に設定
   - 「Branch」を `main` / `/ (root)` に設定して「Save」
   - 数分待つと `https://あなたのユーザー名.github.io/リポジトリ名/` でアクセスできるようになります
5. 表示されたURLを **Safari で開いてホーム画面に追加** すれば完了です

## 更新するとき

このアプリを編集してもらったら、新しい `index.html` を同じ場所に
アップロードし直す（上書き）だけで反映されます。
GitHub Pages は Netlify と違ってビルド回数の制限がないため、
何度アップロードしても無料枠を使い切る心配はありません。
